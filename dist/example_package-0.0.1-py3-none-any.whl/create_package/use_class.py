import class_file

def test():
    ob = class_file.Calculator()
    #show add res
    ob.add(6,9)



if __name__=='__main__':
    test()