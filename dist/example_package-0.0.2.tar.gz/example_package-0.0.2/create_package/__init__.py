

def first_func():
    print('this is an temp function edited')